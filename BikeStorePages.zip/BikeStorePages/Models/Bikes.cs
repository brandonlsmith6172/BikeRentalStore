﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BikeStorePages.Models
{
    public class Bikes
    {
        public int BikeID { get; set; }

        public string Frame { get; set; }

        public string Type { get; set; }

    }
}
