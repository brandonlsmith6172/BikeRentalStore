﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BikeStoreAPI2_WIP_.Models;

namespace BikeStorePages.Models.ViewModels
{
    public class BrandViewModel
    {
        public Brand Brand { get; set; }
    }
}
